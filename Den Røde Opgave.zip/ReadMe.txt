press buttons with left mouse button 
to change color

press s to stop shaking